import camelcase from "camelcase";

console.log(camelcase("--..fooBAR"));