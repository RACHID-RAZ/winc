const add = (a, b) => a + b;

console.log(add(5, 6));