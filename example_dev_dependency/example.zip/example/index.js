const add = (a, b) => {
    return a + b;
};

console.log('Hello world');
console.log(`2 + 3 = ${add(2, 3)}`);
