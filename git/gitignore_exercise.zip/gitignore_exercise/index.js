import { sum } from "lodash-es";
console.log(sum([1, 2, 3]));